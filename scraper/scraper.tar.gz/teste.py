#!/usr/bin/env python3
# coding: utf-8
print('Hello user.')
https://srcm116.cam4.com:443/cam4-edge-live/_definst_/Diamante_08-247-50084b08-ed61-49c0-a6fb-d75b0b156d5b_aac/chunklist_w990461450.m3u8
